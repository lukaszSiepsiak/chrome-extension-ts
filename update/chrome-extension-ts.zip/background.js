!function(){"use strict";chrome.runtime.onStartup.addListener((()=>{console.log("Chrome started")}))}();
//# sourceMappingURL=background.js.map